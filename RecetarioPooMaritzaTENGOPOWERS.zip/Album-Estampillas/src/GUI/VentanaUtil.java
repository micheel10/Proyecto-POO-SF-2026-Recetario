package GUI;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * TIPO: Java Class de utilidades (métodos static).
 *
 * Igual que en el Álbum, pone el título y el logo a las ventanas. Además
 * concentra dos cosas que en el Álbum se repetían en cada pantalla:
 *   - crearPanelConFondo(): el panel con imagen de fondo translúcida.
 *   - icono(): escalar fotos sin deformarlas.
 *
 * IMPORTANTE: las imágenes se leen con getResource("/Imagenes/...") y no con
 * rutas como "src/Imagenes/...". Estas últimas solo funcionan si el programa se
 * ejecuta desde la carpeta del proyecto; con getResource funcionan siempre
 * (también dentro del .jar).
 */
public class VentanaUtil {
    private static final String TITULO = "Recetario";
    private static final String LOGO = "/Imagenes/logoRecetario.png";

    /** Título y logo de la ventana. */
    public static void configurarVentana(JFrame frame) {
        frame.setTitle(TITULO);
        Image logo = cargarImagen(LOGO);
        if (logo != null) {
            frame.setIconImage(logo);
        }
    }

    /** Lee una imagen de /Imagenes (dentro del programa). Devuelve null si no existe. */
    public static Image cargarImagen(String ruta) {
        URL url = VentanaUtil.class.getResource(ruta);
        return (url == null) ? null : new ImageIcon(url).getImage();
    }

    /**
     * Panel (sin layout, para usar setBounds) con una imagen de fondo dibujada
     * con cierta transparencia (0.0 = invisible, 1.0 = totalmente opaca).
     */
    public static JPanel crearPanelConFondo(String ruta, float transparencia) {
        final Image fondo = cargarImagen(ruta);
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fondo != null) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, transparencia));
                    g2.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
                    g2.dispose();
                }
            }
        };
        panel.setLayout(null);
        return panel;
    }

    /** Ícono que LLENA w x h recortando lo que sobre (como "object-fit: cover"): la foto no se deforma. */
    public static ImageIcon icono(BufferedImage origen, int w, int h) {
        double escala = Math.max((double) w / origen.getWidth(), (double) h / origen.getHeight());
        int nuevoAncho = (int) Math.ceil(origen.getWidth() * escala);
        int nuevoAlto = (int) Math.ceil(origen.getHeight() * escala);
        BufferedImage salida = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = salida.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(origen, (w - nuevoAncho) / 2, (h - nuevoAlto) / 2, nuevoAncho, nuevoAlto, null);
        g.dispose();
        return new ImageIcon(salida);
    }

    /** Ícono de un recurso de /Imagenes que CABE completo en maxW x maxH (conserva transparencia). */
    public static ImageIcon iconoRecurso(String ruta, int maxW, int maxH) {
        Image imagen = cargarImagen(ruta);
        if (imagen == null) {
            return null;
        }
        double escala = Math.min((double) maxW / imagen.getWidth(null), (double) maxH / imagen.getHeight(null));
        int w = (int) (imagen.getWidth(null) * escala);
        int h = (int) (imagen.getHeight(null) * escala);
        return new ImageIcon(imagen.getScaledInstance(w, h, Image.SCALE_SMOOTH));
    }
}
