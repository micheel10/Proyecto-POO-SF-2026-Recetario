package GUI;

import Control.ControladorPrincipal;
import Control.Receta;
import Control.Usuario;
import Control.ValidacionException;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * TIPO: Java Class (hereda de JFrame; implementa ActionListener y MensajeError).
 *
 * Panel de administración (equivale a AdminGUI del Álbum): añadir una receta
 * nueva, y consultar / modificar / eliminar una receta escribiendo su CLAVE
 * (el PDF pide que modificar y consultar sean "mediante la clave").
 *
 * La pantalla NO decide nada: busca la receta en el controlador y le pide
 * abrir las ventanas al ControladorGUI.
 */
public class AdminGUI extends JFrame implements ActionListener, MensajeError {
    private static final Color COLOR_TEXTO = new Color(110, 25, 25);

    private ControladorPrincipal controladorPrincipal;
    private Usuario usuarioAdmin;
    private JLabel contador;
    private JTextField claveEntrada;
    private JButton anadir, consultar, modificar, eliminar, verRecetario, cerrarSesion;

    public AdminGUI(ControladorPrincipal controladorPrincipal, Usuario usuarioAdmin) {
        this.controladorPrincipal = controladorPrincipal;
        this.usuarioAdmin = usuarioAdmin;
        VentanaUtil.configurarVentana(this);
        setSize(420, 585);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = VentanaUtil.crearPanelConFondo("/Imagenes/fondoajustesAdmin.png", 0.9f);
        setContentPane(panel);

        JLabel titulo = etiqueta("Panel de administración", 0, 20, 420, 30, 22);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titulo);

        JLabel saludo = etiqueta("Administrador: " + usuarioAdmin.getNombreUsuario(), 0, 52, 420, 22, 14);
        saludo.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(saludo);

        contador = etiqueta("", 0, 76, 420, 22, 13);
        contador.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(contador);

        // --- Sección 1: nueva receta ---
        panel.add(etiqueta("Nueva receta", 30, 115, 360, 24, 16));
        anadir = boton("Añadir receta", 30, 142, 360, 38);
        panel.add(anadir);

        // --- Sección 2: por clave ---
        panel.add(separador(30, 205));
        panel.add(etiqueta("Consultar, modificar o eliminar", 30, 220, 360, 24, 16));
        panel.add(etiqueta("Clave de la receta:", 30, 252, 150, 28, 14));
        claveEntrada = new JTextField();
        claveEntrada.setBounds(185, 252, 205, 28);
        claveEntrada.setToolTipText("Ejemplo: DES-01");
        panel.add(claveEntrada);

        consultar = boton("Consultar", 30, 292, 110, 36);
        modificar = boton("Modificar", 155, 292, 110, 36);
        eliminar = boton("Eliminar", 280, 292, 110, 36);
        panel.add(consultar);
        panel.add(modificar);
        panel.add(eliminar);

        // --- Sección 3: recetario ---
        panel.add(separador(30, 355));
        panel.add(etiqueta("Recetario", 30, 370, 360, 24, 16));
        verRecetario = boton("Ver recetario", 30, 397, 360, 38);
        panel.add(verRecetario);

        cerrarSesion = boton("Cerrar sesión", 30, 490, 360, 36);
        panel.add(cerrarSesion);
    }

    private JLabel etiqueta(String texto, int x, int y, int ancho, int alto, int tamano) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setBounds(x, y, ancho, alto);
        etiqueta.setFont(new Font("Arial", Font.BOLD, tamano));
        etiqueta.setForeground(COLOR_TEXTO);
        return etiqueta;
    }

    private JButton boton(String texto, int x, int y, int ancho, int alto) {
        JButton boton = new JButton(texto);
        boton.setBounds(x, y, ancho, alto);
        boton.addActionListener(this);
        return boton;
    }

    private JSeparator separador(int x, int y) {
        JSeparator separador = new JSeparator();
        separador.setBounds(x, y, 360, 2);
        separador.setForeground(COLOR_TEXTO);
        return separador;
    }

    /** Cada vez que se muestra, actualiza el total de recetas. */
    @Override
    public void setVisible(boolean visible) {
        if (visible) {
            contador.setText("Recetas registradas: " + controladorPrincipal.getControladorRecetas().getCantidadRecetas());
        }
        super.setVisible(visible);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == anadir) {
            controladorPrincipal.getControladorGUI().mostrarFormularioReceta(null);
        } else if (origen == consultar) {
            Receta receta = buscarRecetaEscrita();
            if (receta != null) {
                controladorPrincipal.getControladorGUI().mostrarReceta(receta);
            }
        } else if (origen == modificar) {
            Receta receta = buscarRecetaEscrita();
            if (receta != null) {
                controladorPrincipal.getControladorGUI().mostrarFormularioReceta(receta);
            }
        } else if (origen == eliminar) {
            eliminarRecetaEscrita();
        } else if (origen == verRecetario) {
            controladorPrincipal.getControladorGUI().ocultarAdminPanel();
            controladorPrincipal.getControladorGUI().mostrarRecetario(usuarioAdmin);
        } else if (origen == cerrarSesion) {
            controladorPrincipal.getControladorGUI().cerrarSesion();
        }
    }

    /** Busca la receta cuya clave se escribió; si no existe avisa y devuelve null. */
    private Receta buscarRecetaEscrita() {
        String clave = claveEntrada.getText().trim();
        if (clave.isEmpty()) {
            mensaje(this, "Escribe la clave de la receta (ejemplo: DES-01).");
            return null;
        }
        Receta receta = controladorPrincipal.getControladorRecetas().buscarPorClave(clave);
        if (receta == null) {
            mensaje(this, "No existe ninguna receta con la clave \"" + clave + "\".");
        }
        return receta;
    }

    private void eliminarRecetaEscrita() {
        Receta receta = buscarRecetaEscrita();
        if (receta == null) {
            return;
        }
        if (!confirmar(this, "¿Eliminar la receta " + receta.getClave() + " - " + receta.getNombre()
                + "?\nSe borrarán sus datos, su imagen y su PDF.")) {
            return;
        }
        try {
            controladorPrincipal.getControladorRecetas().eliminarReceta(receta.getClave());
            claveEntrada.setText("");
            setVisible(true);   // refresca el contador
            controladorPrincipal.getControladorGUI().recargarRecetario();
            informacion(this, "Receta eliminada.");
        } catch (ValidacionException ex) {
            mensaje(this, ex.getMessage());
        }
    }
}
