package GUI;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 * TIPO: Java Interface (con métodos default).
 *
 * Igual que en el Álbum: cualquier ventana que la implemente puede mostrar
 * mensajes emergentes sin repetir código. Se usa así:
 *     public class MiVentana extends JFrame implements MensajeError { ... mensaje(this, "Hola"); }
 */
public interface MensajeError {

    /** Aviso de error o de dato incorrecto (ícono de advertencia). */
    default void mensaje(Component padre, String texto) {
        JOptionPane.showMessageDialog(padre, texto, "Atención", JOptionPane.WARNING_MESSAGE);
    }

    /** Aviso informativo (acción realizada con éxito). */
    default void informacion(Component padre, String texto) {
        JOptionPane.showMessageDialog(padre, texto, "Recetario", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Pregunta Sí/No. Devuelve true si la persona eligió "Sí". */
    default boolean confirmar(Component padre, String texto) {
        Object[] opciones = {"Sí", "No"};
        return JOptionPane.showOptionDialog(padre, texto, "Confirmar", JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[1]) == 0;
    }
}
