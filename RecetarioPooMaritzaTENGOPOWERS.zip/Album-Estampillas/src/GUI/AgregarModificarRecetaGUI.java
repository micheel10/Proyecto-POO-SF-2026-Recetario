package GUI;

import Control.CategoriaEnum;
import Control.ControladorPrincipal;
import Control.Receta;
import Control.ValidacionException;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * TIPO: Java Class (hereda de JFrame; implementa ActionListener y MensajeError).
 *
 * Equivale a AgregarModificarTarjetaGUI. El MISMO formulario sirve para dos cosas:
 *   - new AgregarModificarRecetaGUI(cp)          -> AGREGAR  (campos vacíos)
 *   - new AgregarModificarRecetaGUI(cp, receta)  -> MODIFICAR (campos rellenos)
 *
 * Diferencia importante con el Álbum: aquí NO hay validaciones. El formulario
 * recoge lo escrito, se lo pasa al ControladorRecetas y, si algo está mal, solo
 * muestra el mensaje de la ValidacionException.
 */
public class AgregarModificarRecetaGUI extends JFrame implements ActionListener, MensajeError {
    private static final Color COLOR_TEXTO = new Color(110, 25, 25);

    private ControladorPrincipal controladorPrincipal;
    private Receta recetaOriginal;   // null = estamos AGREGANDO
    private File imagenElegida;      // null hasta que se elija una

    private JTextField claveCampo, nombreCampo, tiempoCampo, porcionesCampo;
    private JComboBox<CategoriaEnum> categoriaCombo;
    private JTextArea ingredientesArea, preparacionArea;
    private JLabel nombreImagen, vistaPrevia;
    private JButton elegirImagen, guardar, cancelar;

    /** Constructor para AGREGAR. */
    public AgregarModificarRecetaGUI(ControladorPrincipal controladorPrincipal) {
        this(controladorPrincipal, null);
    }

    /** Constructor para MODIFICAR (receta == null equivale a agregar). */
    public AgregarModificarRecetaGUI(ControladorPrincipal controladorPrincipal, Receta receta) {
        this.controladorPrincipal = controladorPrincipal;
        this.recetaOriginal = receta;
        VentanaUtil.configurarVentana(this);
        setSize(570, 700);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = VentanaUtil.crearPanelConFondo("/Imagenes/fondoRecetas.png", 0.9f);
        setContentPane(panel);

        JLabel titulo = new JLabel(receta == null ? "AGREGAR RECETA" : "MODIFICAR RECETA", SwingConstants.CENTER);
        titulo.setBounds(0, 15, 570, 32);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(COLOR_TEXTO);
        panel.add(titulo);

        panel.add(etiqueta("Clave:", 30, 65));
        claveCampo = campoTexto(180, 65);
        claveCampo.setToolTipText("De 3 a 10 caracteres. Ejemplo: DES-01");
        panel.add(claveCampo);

        panel.add(etiqueta("Nombre:", 30, 103));
        nombreCampo = campoTexto(180, 103);
        panel.add(nombreCampo);

        panel.add(etiqueta("Categoría:", 30, 141));
        categoriaCombo = new JComboBox<>(CategoriaEnum.values());
        categoriaCombo.setBounds(180, 141, 340, 28);
        panel.add(categoriaCombo);

        panel.add(etiqueta("Tiempo (min):", 30, 179));
        tiempoCampo = campoTexto(180, 179);
        panel.add(tiempoCampo);

        panel.add(etiqueta("Porciones:", 30, 217));
        porcionesCampo = campoTexto(180, 217);
        panel.add(porcionesCampo);

        panel.add(etiqueta("<html>Ingredientes:<br><small>(uno por línea)</small></html>", 30, 255, 50));
        ingredientesArea = area();
        panel.add(scroll(ingredientesArea, 180, 255, 340, 95));

        panel.add(etiqueta("<html>Preparación:<br><small>(un paso por línea)</small></html>", 30, 360, 50));
        preparacionArea = area();
        panel.add(scroll(preparacionArea, 180, 360, 340, 125));

        panel.add(etiqueta("Imagen:", 30, 500));
        elegirImagen = boton("Elegir imagen...", 180, 498, 160);
        panel.add(elegirImagen);
        nombreImagen = new JLabel("Ninguna seleccionada");
        nombreImagen.setBounds(180, 534, 170, 36);
        nombreImagen.setFont(new Font("Arial", Font.PLAIN, 11));
        panel.add(nombreImagen);

        vistaPrevia = new JLabel("Vista previa", SwingConstants.CENTER);
        vistaPrevia.setBounds(355, 490, 165, 95);
        vistaPrevia.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        vistaPrevia.setOpaque(true);
        vistaPrevia.setBackground(new Color(255, 252, 245));
        panel.add(vistaPrevia);

        guardar = boton("Guardar", 180, 610, 160);
        cancelar = boton("Cancelar", 360, 610, 160);
        panel.add(guardar);
        panel.add(cancelar);

        if (receta != null) {
            rellenarCampos(receta);
        }
    }

    // ---------- Construcción de componentes ----------
    private JLabel etiqueta(String texto, int x, int y) {
        return etiqueta(texto, x, y, 28);
    }

    private JLabel etiqueta(String texto, int x, int y, int alto) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setBounds(x, y, 145, alto);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 14));
        etiqueta.setForeground(COLOR_TEXTO);
        return etiqueta;
    }

    private JTextField campoTexto(int x, int y) {
        JTextField campo = new JTextField();
        campo.setBounds(x, y, 340, 28);
        return campo;
    }

    private JTextArea area() {
        JTextArea area = new JTextArea();
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setFont(new Font("Arial", Font.PLAIN, 13));
        return area;
    }

    private JScrollPane scroll(JTextArea area, int x, int y, int ancho, int alto) {
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(x, y, ancho, alto);
        return scroll;
    }

    private JButton boton(String texto, int x, int y, int ancho) {
        JButton boton = new JButton(texto);
        boton.setBounds(x, y, ancho, 36);
        boton.addActionListener(this);
        return boton;
    }

    /** Modo MODIFICAR: pone en los campos los datos actuales de la receta. */
    private void rellenarCampos(Receta receta) {
        claveCampo.setText(receta.getClave());
        nombreCampo.setText(receta.getNombre());
        categoriaCombo.setSelectedItem(receta.getCategoria());
        tiempoCampo.setText(String.valueOf(receta.getTiempoCoccion()));
        porcionesCampo.setText(String.valueOf(receta.getPorciones()));
        ingredientesArea.setText(receta.getIngredientes());
        ingredientesArea.setCaretPosition(0);
        preparacionArea.setText(receta.getPreparacion());
        preparacionArea.setCaretPosition(0);
        nombreImagen.setText("<html>Se conserva la imagen actual<br>(elige otra para cambiarla)</html>");
        vistaPrevia.setText("");
        vistaPrevia.setIcon(VentanaUtil.icono(
                controladorPrincipal.getControladorRecetas().cargarImagen(receta), 165, 95));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == elegirImagen) {
            seleccionarImagen();
        } else if (origen == guardar) {
            guardarReceta();
        } else if (origen == cancelar) {
            dispose();
        }
    }

    private void seleccionarImagen() {
        JFileChooser selector = new JFileChooser();
        selector.setDialogTitle("Selecciona la imagen del platillo");
        selector.setFileFilter(new FileNameExtensionFilter("Imágenes (jpg, jpeg, png)", "jpg", "jpeg", "png"));
        if (selector.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        imagenElegida = selector.getSelectedFile();
        nombreImagen.setText(imagenElegida.getName());
        try {
            BufferedImage imagen = ImageIO.read(imagenElegida);
            if (imagen != null) {
                vistaPrevia.setText("");
                vistaPrevia.setIcon(VentanaUtil.icono(imagen, 165, 95));
            }
        } catch (Exception ex) {
            // Si no se puede mostrar la vista previa no pasa nada: el validador avisará al guardar.
        }
    }

    /** Entrega lo escrito al controlador. Si algo no cumple, el controlador lanza ValidacionException. */
    private void guardarReceta() {
        try {
            if (recetaOriginal == null) {
                controladorPrincipal.getControladorRecetas().agregarReceta(
                        claveCampo.getText(), nombreCampo.getText(),
                        (CategoriaEnum) categoriaCombo.getSelectedItem(),
                        ingredientesArea.getText(), preparacionArea.getText(),
                        tiempoCampo.getText(), porcionesCampo.getText(), imagenElegida);
                informacion(this, "Receta agregada correctamente.");
            } else {
                controladorPrincipal.getControladorRecetas().modificarReceta(
                        recetaOriginal.getClave(),
                        claveCampo.getText(), nombreCampo.getText(),
                        (CategoriaEnum) categoriaCombo.getSelectedItem(),
                        ingredientesArea.getText(), preparacionArea.getText(),
                        tiempoCampo.getText(), porcionesCampo.getText(), imagenElegida);
                informacion(this, "Receta modificada correctamente.");
            }
            dispose();
            controladorPrincipal.getControladorGUI().recargarRecetario();
        } catch (ValidacionException ex) {
            mensaje(this, ex.getMessage());   // la ventana sigue abierta para corregir
        }
    }
}