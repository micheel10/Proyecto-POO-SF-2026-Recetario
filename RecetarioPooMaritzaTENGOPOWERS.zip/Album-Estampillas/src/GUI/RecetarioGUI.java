package GUI;

import Control.CategoriaEnum;
import Control.ControladorPrincipal;
import Control.Receta;
import Control.RolEnum;
import Control.Usuario;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * TIPO: Java Class (hereda de JFrame; implementa ActionListener y MensajeError).
 *
 * Equivale a AlbumGUI: la pantalla grande con todas las "estampillas" (recetas)
 * en una cuadrícula (Figura 1 del PDF). Se filtran por categoría o por texto, y
 * al hacer clic en una tarjeta se abre su detalle.
 *
 * Cada tarjeta se arma con crearTarjeta(); al pasar el mouse el borde se
 * ilumina, igual que las tarjetas del Álbum.
 */
public class RecetarioGUI extends JFrame implements ActionListener, MensajeError {
    private static final String TODAS = "Todas las categorías";
    private static final int ANCHO_TARJETA = 190;
    private static final int ALTO_FOTO = 170;
    private static final int ALTO_INFO = 80;

    private ControladorPrincipal controladorPrincipal;
    private Usuario usuario;
    private JComboBox<Object> comboCategoria;
    private JTextField campoBusqueda;
    private JButton buscar, limpiar, panelAdmin, cerrarSesion;
    private JLabel contador;
    private JPanel zonaTarjetas;

    // Caché de fotos ya escaladas: filtrar no vuelve a procesar las mismas imágenes.
    private HashMap<String, ImageIcon> iconos = new HashMap<>();

    public RecetarioGUI(Usuario usuario, ControladorPrincipal controladorPrincipal) {
        this.usuario = usuario;
        this.controladorPrincipal = controladorPrincipal;
        VentanaUtil.configurarVentana(this);
        setSize(1350, 720);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = VentanaUtil.crearPanelConFondo("/Imagenes/fondoRecetario.jpg", 0.9f);
        setContentPane(panel);

        // --- Encabezado ---
        JLabel titulo = new JLabel("RECETARIO", SwingConstants.CENTER);
        titulo.setBounds(0, 12, 1350, 36);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));
        titulo.setForeground(Color.WHITE);
        panel.add(titulo);

        String tipo = (usuario.getTipoUsuario() == RolEnum.ADMINISTRADOR) ? "Administrador" : "Usuario";
        JLabel quien = new JLabel(tipo + ": " + usuario.getNombreUsuario());
        quien.setBounds(30, 54, 500, 24);
        quien.setFont(new Font("Arial", Font.BOLD, 15));
        quien.setForeground(Color.WHITE);
        panel.add(quien);

        cerrarSesion = new JButton("Cerrar sesión");
        cerrarSesion.setBounds(1190, 52, 130, 28);
        cerrarSesion.addActionListener(this);
        panel.add(cerrarSesion);

        if (usuario.getTipoUsuario() == RolEnum.ADMINISTRADOR) {
            panelAdmin = new JButton("Panel de administración");
            panelAdmin.setBounds(930, 52, 245, 28);
            panelAdmin.addActionListener(this);
            panel.add(panelAdmin);
        }

        // --- Filtros ---
        JPanel filtros = new JPanel(null);
        filtros.setBounds(30, 90, 1290, 52);
        filtros.setBackground(new Color(255, 255, 255, 215));
        filtros.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        panel.add(filtros);

        filtros.add(etiquetaFiltro("Categoría:", 15, 13, 100));
        comboCategoria = new JComboBox<>();
        comboCategoria.addItem(TODAS);
        for (CategoriaEnum c : CategoriaEnum.values()) {
            comboCategoria.addItem(c);
        }
        comboCategoria.setBounds(120, 12, 220, 28);
        comboCategoria.addActionListener(this);
        filtros.add(comboCategoria);

        filtros.add(etiquetaFiltro("Buscar (nombre o clave):", 370, 13, 230));
        campoBusqueda = new JTextField();
        campoBusqueda.setBounds(610, 12, 210, 28);
        campoBusqueda.addActionListener(this);   // Enter también busca
        filtros.add(campoBusqueda);

        buscar = new JButton("Buscar");
        buscar.setBounds(830, 12, 95, 28);
        buscar.addActionListener(this);
        filtros.add(buscar);

        limpiar = new JButton("Limpiar");
        limpiar.setBounds(935, 12, 95, 28);
        limpiar.addActionListener(this);
        filtros.add(limpiar);

        contador = new JLabel("", SwingConstants.RIGHT);
        contador.setBounds(1050, 13, 225, 26);
        contador.setFont(new Font("Arial", Font.BOLD, 14));
        filtros.add(contador);

        // --- Cuadrícula de tarjetas con desplazamiento ---
        zonaTarjetas = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 5));
        zonaTarjetas.setOpaque(false);
        JScrollPane scroll = new JScrollPane(zonaTarjetas);
        scroll.setBounds(30, 155, 1290, 505);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(24);
        panel.add(scroll);

        JLabel pie = new JLabel("Haz clic en una receta para ver sus ingredientes y su preparación.",
                SwingConstants.CENTER);
        pie.setBounds(0, 668, 1350, 22);
        pie.setFont(new Font("Arial", Font.PLAIN, 13));
        pie.setForeground(Color.WHITE);
        panel.add(pie);

        recargarRecetario();
    }

    private JLabel etiquetaFiltro(String texto, int x, int y, int ancho) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setBounds(x, y, ancho, 26);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 14));
        return etiqueta;
    }

    /** Vuelve a pedir las recetas (con el filtro actual) y a dibujar las tarjetas. */
    public void recargarRecetario() {
        Object elegido = comboCategoria.getSelectedItem();
        CategoriaEnum categoria = (elegido instanceof CategoriaEnum) ? (CategoriaEnum) elegido : null;

        ArrayList<Receta> recetas = controladorPrincipal.getControladorRecetas()
                .filtrar(categoria, campoBusqueda.getText());

        zonaTarjetas.removeAll();
        if (recetas.isEmpty()) {
            JLabel vacio = new JLabel("No hay recetas que coincidan con la búsqueda.");
            vacio.setFont(new Font("Arial", Font.BOLD, 18));
            vacio.setForeground(Color.WHITE);
            zonaTarjetas.add(vacio);
        } else {
            // Un panel con 6 columnas; FlowLayout lo mantiene centrado y sin estirarse.
            JPanel cuadricula = new JPanel(new GridLayout(0, 6, 14, 14));
            cuadricula.setOpaque(false);
            for (Receta receta : recetas) {
                cuadricula.add(crearTarjeta(receta));
            }
            zonaTarjetas.add(cuadricula);
        }
        contador.setText("Mostrando " + recetas.size() + " de "
                + controladorPrincipal.getControladorRecetas().getCantidadRecetas());
        zonaTarjetas.revalidate();
        zonaTarjetas.repaint();
    }

    /** Una tarjeta: foto arriba; abajo, nombre en negrita y "clave · tiempo". */
    private JPanel crearTarjeta(Receta receta) {
        JPanel tarjeta = new JPanel(new BorderLayout());
        tarjeta.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        tarjeta.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel foto = new JLabel(obtenerIcono(receta));
        tarjeta.add(foto, BorderLayout.CENTER);

        JPanel info = new JPanel(null);
        info.setPreferredSize(new java.awt.Dimension(ANCHO_TARJETA, ALTO_INFO));
        info.setBackground(new Color(20, 60, 35));

        // <body width=...> hace que el nombre largo se parta en varias líneas.
        JLabel nombre = new JLabel("<html><body width='176'><center>" + html(receta.getNombre())
                + "</center></body></html>");
        nombre.setBounds(5, 5, 180, 46);
        nombre.setVerticalAlignment(SwingConstants.TOP);
        nombre.setFont(new Font("Arial", Font.BOLD, 12));
        nombre.setForeground(Color.WHITE);
        info.add(nombre);

        JLabel datos = new JLabel(receta.getClave() + "  ·  " + receta.getTiempoCoccion() + " min",
                SwingConstants.CENTER);
        datos.setBounds(0, 55, ANCHO_TARJETA, 20);
        datos.setFont(new Font("Arial", Font.PLAIN, 12));
        datos.setForeground(new Color(255, 225, 110));
        info.add(datos);
        tarjeta.add(info, BorderLayout.SOUTH);

        tarjeta.setToolTipText(receta.getCategoria().getNombre() + " - " + receta.getNombre());
        tarjeta.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                controladorPrincipal.getControladorGUI().mostrarReceta(receta);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                tarjeta.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                tarjeta.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            }
        });
        return tarjeta;
    }

    private ImageIcon obtenerIcono(Receta receta) {
        String llave = receta.getImagen() + "|" + receta.getClave() + "|" + receta.getNombre() + "|"
                + receta.getCategoria();
        ImageIcon icono = iconos.get(llave);
        if (icono == null) {
            icono = VentanaUtil.icono(controladorPrincipal.getControladorRecetas().cargarImagen(receta),
                    ANCHO_TARJETA, ALTO_FOTO);
            iconos.put(llave, icono);
        }
        return icono;
    }

    /** Evita que un nombre con símbolos < > & rompa el HTML de la etiqueta. */
    private static String html(String texto) {
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == comboCategoria || origen == buscar || origen == campoBusqueda) {
            recargarRecetario();
        } else if (origen == limpiar) {
            campoBusqueda.setText("");
            comboCategoria.setSelectedIndex(0);   // dispara recargarRecetario por el combo
            recargarRecetario();
        } else if (origen == panelAdmin) {
            controladorPrincipal.getControladorGUI().ocultarRecetario();
            controladorPrincipal.getControladorGUI().setUsuarioAdmin(usuario);
            controladorPrincipal.getControladorGUI().mostrarAdminPanel();
        } else if (origen == cerrarSesion) {
            controladorPrincipal.getControladorGUI().cerrarSesion();
        }
    }
}
