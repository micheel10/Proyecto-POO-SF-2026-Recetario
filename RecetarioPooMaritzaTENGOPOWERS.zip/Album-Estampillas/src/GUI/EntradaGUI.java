package GUI;

import Control.ControladorPrincipal;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * TIPO: Java Class ABSTRACTA (hereda de JFrame e implementa ActionListener y MensajeError).
 *
 * Es la "plantilla" de las pantallas de entrada (inicio de sesión y registro),
 * igual que en el Álbum: dibuja el fondo, el logo y los campos usuario /
 * contraseña. Cada hija solo escribe su actionPerformed (qué hacer al presionar).
 *
 * Correcciones respecto al Álbum:
 *  - La contraseña es un JPasswordField (antes se veía lo que se escribía).
 *  - Las etiquetas son más anchas (antes se leía "Contrasen..." y "Registra...").
 */
public abstract class EntradaGUI extends JFrame implements ActionListener, MensajeError {
    protected ControladorPrincipal controladorPrincipal;
    protected JPanel panel;
    protected JLabel sesion;
    protected JTextField usuarioEntrada;
    protected JPasswordField contraseniaEntrada;
    protected JButton aceptar;
    protected JButton cambiar;

    public EntradaGUI(ControladorPrincipal controladorPrincipal, String textoSesion,
            String textoAceptar, String textoCambiar) {
        this.controladorPrincipal = controladorPrincipal;
        VentanaUtil.configurarVentana(this);
        setSize(400, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        panel = VentanaUtil.crearPanelConFondo("/Imagenes/fondopantallainicio.png", 0.9f);
        setContentPane(panel);

        JLabel bienvenida = etiqueta("Bienvenido al Recetario", 0, 20, 400, 30, 20);
        bienvenida.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(bienvenida);

        JLabel logo = new JLabel(VentanaUtil.iconoRecurso("/Imagenes/logoRecetario.png", 190, 190));
        logo.setBounds(105, 65, 190, 190);
        panel.add(logo);

        sesion = etiqueta(textoSesion, 0, 268, 400, 30, 17);
        sesion.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(sesion);

        panel.add(etiqueta("Usuario:", 30, 320, 115, 30, 16));
        usuarioEntrada = new JTextField();
        usuarioEntrada.setBounds(150, 320, 200, 30);
        panel.add(usuarioEntrada);

        panel.add(etiqueta("Contraseña:", 30, 370, 115, 30, 16));
        contraseniaEntrada = new JPasswordField();
        contraseniaEntrada.setBounds(150, 370, 200, 30);
        panel.add(contraseniaEntrada);

        cambiar = new JButton(textoCambiar);
        cambiar.setBounds(30, 430, 150, 34);
        cambiar.addActionListener(this);
        panel.add(cambiar);

        aceptar = new JButton(textoAceptar);
        aceptar.setBounds(210, 430, 140, 34);
        aceptar.addActionListener(this);
        panel.add(aceptar);

        getRootPane().setDefaultButton(aceptar);   // Enter = Aceptar
    }

    /** Etiqueta blanca Arial en negrita (el estilo de letra del Álbum). */
    protected JLabel etiqueta(String texto, int x, int y, int ancho, int alto, int tamano) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setBounds(x, y, ancho, alto);
        etiqueta.setFont(new Font("Arial", Font.BOLD, tamano));
        etiqueta.setForeground(Color.WHITE);
        return etiqueta;
    }

    public void limpiarCampos() {
        usuarioEntrada.setText("");
        contraseniaEntrada.setText("");
    }

    protected String getUsuarioEscrito() {
        return usuarioEntrada.getText().trim().toLowerCase();
    }

    protected String getContraseniaEscrita() {
        return new String(contraseniaEntrada.getPassword());
    }
}
