package GUI;

import Control.ControladorPrincipal;
import Control.Receta;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * TIPO: Java Class (hereda de JFrame; implementa ActionListener y MensajeError).
 *
 * Equivale a TarjetaGUI: el detalle de UNA receta (Figura 2 del PDF) con foto,
 * datos, ingredientes y preparación, más los botones para VER, IMPRIMIR y
 * DESCARGAR el PDF.
 *
 * Al cerrarla solo se cierra esta ventana (DISPOSE_ON_CLOSE), no el programa.
 */
public class RecetaGUI extends JFrame implements ActionListener, MensajeError {
    private static final Color COLOR_TEXTO = new Color(110, 25, 25);

    private ControladorPrincipal controladorPrincipal;
    private Receta receta;
    private JButton verPdf, imprimirPdf, descargarPdf, cerrar;

    public RecetaGUI(Receta receta, ControladorPrincipal controladorPrincipal) {
        this.receta = receta;
        this.controladorPrincipal = controladorPrincipal;
        VentanaUtil.configurarVentana(this);
        setSize(610, 760);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = VentanaUtil.crearPanelConFondo("/Imagenes/fondoRecetas.png", 0.9f);
        setContentPane(panel);

        // --- Nombre ---
        JLabel nombre = new JLabel("<html><body width='550'><center>" + html(receta.getNombre())
                + "</center></body></html>", SwingConstants.CENTER);
        nombre.setBounds(20, 10, 570, 56);
        nombre.setFont(new Font("Arial", Font.BOLD, 22));
        nombre.setForeground(COLOR_TEXTO);
        panel.add(nombre);

        // --- Foto y datos ---
        JPanel datos = new JPanel(null);
        datos.setBounds(20, 75, 570, 190);
        datos.setBackground(new Color(255, 252, 245));
        datos.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        panel.add(datos);

        JLabel foto = new JLabel(VentanaUtil.icono(
                controladorPrincipal.getControladorRecetas().cargarImagen(receta), 240, 170));
        foto.setBounds(10, 9, 240, 170);
        datos.add(foto);

        datos.add(dato("Clave: " + receta.getClave(), 270, 15));
        datos.add(dato("Categoría: " + receta.getCategoria().getNombre(), 270, 55));
        datos.add(dato("Tiempo de cocción: " + receta.getTiempoCoccion() + " min", 270, 95));
        datos.add(dato("Porciones: " + receta.getPorciones(), 270, 135));

        // --- Ingredientes y preparación ---
        panel.add(titulo("Ingredientes", 20, 280));
        panel.add(areaTexto(receta.getIngredientes(), 20, 308, 570, 130));

        panel.add(titulo("Modo de preparación", 20, 450));
        panel.add(areaTexto(receta.getPreparacion(), 20, 478, 570, 170));

        // --- Botones ---
        verPdf = boton("Ver PDF", 20, 668, 130);
        imprimirPdf = boton("Imprimir", 160, 668, 130);
        descargarPdf = boton("Descargar PDF", 300, 668, 160);
        cerrar = boton("Cerrar", 470, 668, 120);
        panel.add(verPdf);
        panel.add(imprimirPdf);
        panel.add(descargarPdf);
        panel.add(cerrar);
    }

    private JLabel dato(String texto, int x, int y) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setBounds(x, y, 285, 30);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 15));
        return etiqueta;
    }

    private JLabel titulo(String texto, int x, int y) {
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setBounds(x, y, 400, 26);
        etiqueta.setFont(new Font("Arial", Font.BOLD, 17));
        etiqueta.setForeground(COLOR_TEXTO);
        return etiqueta;
    }

    private JScrollPane areaTexto(String texto, int x, int y, int ancho, int alto) {
        JTextArea area = new JTextArea(texto);
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);   // corta por palabras completas
        area.setFont(new Font("Arial", Font.PLAIN, 14));
        area.setBackground(new Color(255, 252, 245));
        area.setMargin(new java.awt.Insets(6, 8, 6, 8));
        area.setCaretPosition(0);
        JScrollPane scroll = new JScrollPane(area);
        scroll.setBounds(x, y, ancho, alto);
        return scroll;
    }

    private JButton boton(String texto, int x, int y, int ancho) {
        JButton boton = new JButton(texto);
        boton.setBounds(x, y, ancho, 36);
        boton.addActionListener(this);
        return boton;
    }

    private static String html(String texto) {
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == verPdf) {
            abrirPdf(false);
        } else if (origen == imprimirPdf) {
            abrirPdf(true);
        } else if (origen == descargarPdf) {
            descargarPdf();
        } else if (origen == cerrar) {
            dispose();
        }
    }

    /** Genera el PDF y lo abre (o lo manda a imprimir) con el programa del sistema. */
    private void abrirPdf(boolean imprimir) {
        try {
            File pdf = controladorPrincipal.getControladorRecetas().generarPdf(receta);
            if (!Desktop.isDesktopSupported()) {
                informacion(this, "Tu sistema no permite abrir archivos desde Java.\nEl PDF está en:\n"
                        + pdf.getAbsolutePath());
                return;
            }
            Desktop escritorio = Desktop.getDesktop();
            if (imprimir && escritorio.isSupported(Desktop.Action.PRINT)) {
                escritorio.print(pdf);
            } else if (escritorio.isSupported(Desktop.Action.OPEN)) {
                escritorio.open(pdf);
                if (imprimir) {
                    informacion(this, "Se abrió el PDF. Usa Ctrl + P en tu visor para imprimirlo.");
                }
            } else {
                informacion(this, "El PDF está en:\n" + pdf.getAbsolutePath());
            }
        } catch (IOException | RuntimeException ex) {
            mensaje(this, "No se pudo abrir o imprimir el PDF: " + ex.getMessage());
        }
    }

    private void descargarPdf() {
        JFileChooser selector = new JFileChooser();
        selector.setDialogTitle("Guardar receta en PDF");
        selector.setFileFilter(new FileNameExtensionFilter("Documento PDF (*.pdf)", "pdf"));
        // Nombre sugerido sin símbolos raros y con guiones bajos en lugar de espacios.
        String sugerido = receta.getNombre().replaceAll("[^\\p{L}\\p{N} ]", "").trim().replace(' ', '_');
        selector.setSelectedFile(new File(sugerido + ".pdf"));
        if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File destino = selector.getSelectedFile();
        if (!destino.getName().toLowerCase().endsWith(".pdf")) {
            destino = new File(destino.getParentFile(), destino.getName() + ".pdf");
        }
        if (destino.exists() && !confirmar(this, "El archivo ya existe. ¿Deseas reemplazarlo?")) {
            return;
        }
        try {
            controladorPrincipal.getControladorRecetas().exportarPdf(receta, destino);
            informacion(this, "PDF guardado en:\n" + destino.getAbsolutePath());
        } catch (IOException ex) {
            mensaje(this, "No se pudo guardar el PDF: " + ex.getMessage());
        }
    }
}
