package GUI;

import Control.ControladorPrincipal;
import Control.ControladorUsuario;
import Control.RolEnum;
import Control.Usuario;
import java.awt.event.ActionEvent;

/**
 * TIPO: Java Class (hereda de EntradaGUI).
 *
 * Pantalla de inicio de sesión. Si la persona es administrador va al panel de
 * administración; si es usuario común, directo al recetario.
 */
public class InicioSesionGUI extends EntradaGUI {

    public InicioSesionGUI(ControladorPrincipal controladorPrincipal) {
        super(controladorPrincipal, "Iniciar Sesión", "Aceptar", "Registrarse");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == aceptar) {
            iniciarSesion();
        } else if (e.getSource() == cambiar) {
            controladorPrincipal.getControladorGUI().ocultarInicioSesion();
            controladorPrincipal.getControladorGUI().mostrarRegistro();
        }
    }

    private void iniciarSesion() {
        String nombre = getUsuarioEscrito();
        String contrasenia = getContraseniaEscrita();

        if (nombre.isEmpty() || contrasenia.isEmpty()) {
            mensaje(this, "Escribe tu usuario y tu contraseña.");
            return;
        }

        ControladorUsuario controladorUsuario = controladorPrincipal.getControladorUsuario();
        if (!controladorUsuario.validarUsuario(nombre)) {
            mensaje(this, "Usuario no encontrado.");
        } else if (!controladorUsuario.validarContrasenia(nombre, contrasenia)) {
            mensaje(this, "Contraseña incorrecta.");
            contraseniaEntrada.setText("");
        } else {
            Usuario usuario = controladorUsuario.obtenerUsuario(nombre);
            controladorPrincipal.getControladorGUI().ocultarInicioSesion();
            if (usuario.getTipoUsuario() == RolEnum.ADMINISTRADOR) {
                controladorPrincipal.getControladorGUI().setUsuarioAdmin(usuario);
                controladorPrincipal.getControladorGUI().mostrarAdminPanel();
            } else {
                controladorPrincipal.getControladorGUI().mostrarRecetario(usuario);
            }
        }
    }
}
