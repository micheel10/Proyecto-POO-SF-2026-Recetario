package GUI;

import Control.ControladorPrincipal;
import Control.RolEnum;
import Control.ValidacionException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPasswordField;

/**
 * TIPO: Java Class (hereda de EntradaGUI).
 *
 * Pantalla para crear una cuenta nueva. Para registrarse como administrador
 * hay que escribir la clave de administrador. Las validaciones las hace el
 * ControladorUsuario; esta pantalla solo muestra su mensaje si algo falla.
 */
public class RegistroGUI extends EntradaGUI {
    private JComboBox<RolEnum> tipoUsuario;
    private JPasswordField claveAdmin;
    private JLabel etiquetaClave;

    public RegistroGUI(ControladorPrincipal controladorPrincipal) {
        super(controladorPrincipal, "Registro", "Registrar", "Volver");

        // Los botones del padre se reubican para dejar espacio a los campos nuevos.
        cambiar.setBounds(30, 530, 150, 34);
        aceptar.setBounds(210, 530, 140, 34);

        panel.add(etiqueta("Tipo:", 30, 420, 115, 30, 16));
        tipoUsuario = new JComboBox<>(RolEnum.values());
        tipoUsuario.setBounds(150, 420, 200, 30);
        tipoUsuario.addActionListener(this);
        panel.add(tipoUsuario);

        etiquetaClave = etiqueta("Clave admin:", 30, 470, 115, 30, 16);
        panel.add(etiquetaClave);
        claveAdmin = new JPasswordField();
        claveAdmin.setBounds(150, 470, 200, 30);
        panel.add(claveAdmin);

        actualizarCampoClave();
    }

    /** La clave de administrador solo se pide si el tipo elegido es ADMINISTRADOR. */
    private void actualizarCampoClave() {
        boolean esAdmin = tipoUsuario.getSelectedItem() == RolEnum.ADMINISTRADOR;
        claveAdmin.setEnabled(esAdmin);
        etiquetaClave.setVisible(esAdmin);
        claveAdmin.setVisible(esAdmin);
        if (!esAdmin) {
            claveAdmin.setText("");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == tipoUsuario) {
            actualizarCampoClave();
        } else if (e.getSource() == aceptar) {
            registrar();
        } else if (e.getSource() == cambiar) {
            controladorPrincipal.getControladorGUI().ocultarRegistro();
            controladorPrincipal.getControladorGUI().mostrarInicioSesion();
        }
    }

    private void registrar() {
        try {
            controladorPrincipal.getControladorUsuario().registrarUsuario(
                    usuarioEntrada.getText(),
                    getContraseniaEscrita(),
                    (RolEnum) tipoUsuario.getSelectedItem(),
                    new String(claveAdmin.getPassword()));
            informacion(this, "Usuario registrado con éxito. Ya puedes iniciar sesión.");
            controladorPrincipal.getControladorGUI().ocultarRegistro();
            controladorPrincipal.getControladorGUI().mostrarInicioSesion();
        } catch (ValidacionException ex) {
            mensaje(this, ex.getMessage());   // el controlador ya redactó el mensaje
        }
    }

    @Override
    public void limpiarCampos() {
        super.limpiarCampos();
        tipoUsuario.setSelectedItem(RolEnum.USUARIO);
        claveAdmin.setText("");
    }
}
