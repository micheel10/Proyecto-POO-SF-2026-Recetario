package Main;

import javax.swing.SwingUtilities;

/**
 * TIPO: Java Class (clase con método main = punto de entrada).
 *
 * Igual que el Main del Álbum: solo crea el controlador y pide la primera
 * pantalla. Lo único nuevo es invokeLater: Swing debe crear sus ventanas en su
 * propio hilo (el "Event Dispatch Thread"); así se evitan ventanas congeladas.
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            var controlador = new Control.ControladorPrincipal();
            controlador.getControladorGUI().mostrarInicioSesion();
        });
    }

}