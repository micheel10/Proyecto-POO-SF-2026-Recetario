package Archivos;

import Control.Receta;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import javax.imageio.ImageIO;

/**
 * TIPO: Java Class (con constructor privado y un método static de entrada).
 *
 * Crea un PDF de una receta SIN librerías externas, escribiendo directamente
 * el formato PDF (que en el fondo es texto estructurado).
 * Incluye TODOS los datos que se piden al agregar una receta:
 * clave, nombre, categoría, ingredientes, preparación, tiempo, porciones e imagen.
 *
 * ¿Cómo es un PDF por dentro? Una lista de "objetos" numerados:
 *   1 = catálogo, 2 = lista de páginas, 3 y 4 = tipos de letra,
 *   5 = la imagen (si hay), y luego, por cada página, un objeto "página"
 *   y un objeto "contenido" (los comandos de dibujo: texto, imagen...).
 * Al final va una tabla "xref" con la posición en bytes de cada objeto.
 *
 * Limitación: usa letra Helvetica estándar, que cubre acentos y ñ del español
 * pero no emojis ni símbolos raros (se cambian por "?").
 * Para PDFs más sofisticados en un proyecto real se usaría Apache PDFBox o iText.
 */
public final class GeneradorPDF {

    // Medidas en "puntos" (1 punto = 1/72 de pulgada). Tamaño A4.
    private static final int ANCHO = 595;
    private static final int ALTO = 842;
    private static final int MARGEN = 50;
    private static final int ANCHO_UTIL = ANCHO - 2 * MARGEN;

    private final List<StringBuilder> paginas = new ArrayList<>();
    private StringBuilder paginaActual;
    private double y;                 // posición vertical actual (se baja al escribir)
    private byte[] jpeg;              // bytes de la imagen ya convertida a JPG
    private int jpegAncho, jpegAlto;

    private GeneradorPDF() { }

    /** Punto de entrada: genera el PDF de la receta y lo escribe en 'destino'. */
    public static void generar(Receta receta, BufferedImage imagen, File destino) throws IOException {
        GeneradorPDF pdf = new GeneradorPDF();
        pdf.construir(receta, imagen);
        pdf.escribir(destino);
    }

    // ------------------------------------------------------------------
    //  1) Armado del contenido
    // ------------------------------------------------------------------

    private void construir(Receta r, BufferedImage imagen) throws IOException {
        nuevaPagina();

        texto(r.getNombre(), true, 22, 0);
        texto(r.getCategoria().getNombre() + "   |   Clave: " + r.getClave(), false, 11, 0);
        texto("Tiempo de cocción: " + r.getTiempoCoccion() + " min   |   Porciones: " + r.getPorciones(), false, 11, 0);
        espacio(10);

        if (imagen != null) {
            colocarImagen(imagen);
        }

        texto("Ingredientes", true, 15, 0);
        espacio(2);
        for (String ingrediente : r.getListaIngredientes()) {
            texto("- " + ingrediente, false, 11, 10);
        }
        espacio(10);

        texto("Modo de preparación", true, 15, 0);
        espacio(2);
        int numero = 1;
        for (String paso : r.getListaPasos()) {
            texto(numero++ + ". " + paso, false, 11, 10);
            espacio(2);
        }
    }

    private void nuevaPagina() {
        paginaActual = new StringBuilder();
        paginas.add(paginaActual);
        y = ALTO - MARGEN;
    }

    private void espacio(double puntos) {
        y -= puntos;
    }

    /** Escribe un texto, partiéndolo en varias líneas si no cabe a lo ancho. */
    private void texto(String contenido, boolean negrita, int tamano, int sangria) {
        // Ancho medio de un carácter de Helvetica ≈ 0.5 del tamaño (un poco más en negrita).
        double anchoCaracter = tamano * (negrita ? 0.56 : 0.52);
        int maxCaracteres = (int) ((ANCHO_UTIL - sangria) / anchoCaracter);

        for (String linea : partirEnLineas(limpiar(contenido), maxCaracteres)) {
            if (y - tamano * 1.4 < MARGEN) {
                nuevaPagina();   // si ya no cabe, seguimos en una página nueva
            }
            y -= tamano * 1.4;
            // BT/ET = inicio/fin de texto, Tf = fuente y tamaño, Td = posición, Tj = mostrar
            paginaActual.append("BT /").append(negrita ? "F2" : "F1").append(' ').append(tamano)
                    .append(" Tf ").append(numero(MARGEN + sangria)).append(' ').append(numero(y))
                    .append(" Td (").append(escaparPdf(linea)).append(") Tj ET\n");
        }
    }

    private void colocarImagen(BufferedImage original) throws IOException {
        // 1) Reducimos y convertimos a RGB para que ocupe poco y sea compatible con JPG.
        double escala = Math.min(1.0, 800.0 / original.getWidth());
        int w = (int) (original.getWidth() * escala);
        int h = (int) (original.getHeight() * escala);
        BufferedImage rgb = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgb.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, h);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(original, 0, 0, w, h, null);
        g.dispose();

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageIO.write(rgb, "jpg", bytes);
        jpeg = bytes.toByteArray();
        jpegAncho = w;
        jpegAlto = h;

        // 2) Tamaño en la página: máximo 300 x 220 puntos, conservando la proporción.
        double factor = Math.min(300.0 / w, 220.0 / h);
        double anchoPt = w * factor;
        double altoPt = h * factor;

        // 3) "q ... Q" guarda/restaura estado; "cm" coloca y escala; "Do" dibuja la imagen.
        double abajo = y - altoPt;
        paginaActual.append("q ").append(numero(anchoPt)).append(" 0 0 ").append(numero(altoPt))
                .append(' ').append(numero(MARGEN)).append(' ').append(numero(abajo))
                .append(" cm /Im1 Do Q\n");
        y = abajo - 16;
    }

    // ------------------------------------------------------------------
    //  2) Escritura del archivo PDF
    // ------------------------------------------------------------------

    private void escribir(File destino) throws IOException {
        boolean hayImagen = (jpeg != null);
        int primeraPagina = hayImagen ? 6 : 5;     // número del primer objeto "página"
        int totalPaginas = paginas.size();

        // TreeMap = ordenado por número de objeto, que es como deben ir en el archivo.
        Map<Integer, byte[]> objetos = new TreeMap<>();

        objetos.put(1, bytes("<< /Type /Catalog /Pages 2 0 R >>"));

        StringBuilder hijos = new StringBuilder();
        for (int i = 0; i < totalPaginas; i++) {
            hijos.append(primeraPagina + 2 * i).append(" 0 R ");
        }
        objetos.put(2, bytes("<< /Type /Pages /Kids [" + hijos + "] /Count " + totalPaginas + " >>"));

        objetos.put(3, bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"));
        objetos.put(4, bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"));

        if (hayImagen) {
            objetos.put(5, flujo("<< /Type /XObject /Subtype /Image /Width " + jpegAncho
                    + " /Height " + jpegAlto + " /ColorSpace /DeviceRGB /BitsPerComponent 8"
                    + " /Filter /DCTDecode /Length " + jpeg.length + " >>", jpeg));
        }

        String recursos = "/Resources << /Font << /F1 3 0 R /F2 4 0 R >>"
                + (hayImagen ? " /XObject << /Im1 5 0 R >>" : "") + " >>";

        for (int i = 0; i < totalPaginas; i++) {
            int idPagina = primeraPagina + 2 * i;
            int idContenido = idPagina + 1;
            objetos.put(idPagina, bytes("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + ANCHO + " " + ALTO + "] "
                    + recursos + " /Contents " + idContenido + " 0 R >>"));

            byte[] contenido = bytes(paginas.get(i).toString());
            objetos.put(idContenido, flujo("<< /Length " + contenido.length + " >>", contenido));
        }

        // ---- Ensamblado final: cabecera + objetos + tabla xref + trailer ----
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        salida.write(bytes("%PDF-1.4\n"));

        int maximo = objetos.size();
        long[] posiciones = new long[maximo + 1];
        for (Map.Entry<Integer, byte[]> o : objetos.entrySet()) {
            posiciones[o.getKey()] = salida.size();      // dónde empieza este objeto
            salida.write(bytes(o.getKey() + " 0 obj\n"));
            salida.write(o.getValue());
            salida.write(bytes("\nendobj\n"));
        }

        long inicioXref = salida.size();
        StringBuilder xref = new StringBuilder("xref\n0 " + (maximo + 1) + "\n");
        xref.append("0000000000 65535 f \n");
        for (int id = 1; id <= maximo; id++) {
            xref.append(String.format(Locale.US, "%010d 00000 n \n", posiciones[id]));
        }
        xref.append("trailer\n<< /Size ").append(maximo + 1).append(" /Root 1 0 R >>\n")
            .append("startxref\n").append(inicioXref).append("\n%%EOF\n");
        salida.write(bytes(xref.toString()));

        if (destino.getParentFile() != null) {
            destino.getParentFile().mkdirs();
        }
        Files.write(destino.toPath(), salida.toByteArray());
    }

    // ------------------------------------------------------------------
    //  3) Utilidades pequeñas
    // ------------------------------------------------------------------

    /** Construye un objeto "stream": diccionario + datos binarios. */
    private static byte[] flujo(String diccionario, byte[] datos) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        b.write(bytes(diccionario + "\nstream\n"));
        b.write(datos);
        b.write(bytes("\nendstream"));
        return b.toByteArray();
    }

    /** ISO-8859-1 asigna 1 byte por carácter, que es lo que usa WinAnsiEncoding (á, é, ñ...). */
    private static byte[] bytes(String texto) {
        return texto.getBytes(StandardCharsets.ISO_8859_1);
    }

    /** Números con PUNTO decimal siempre (con coma, en un PC en español, el PDF se dañaría). */
    private static String numero(double valor) {
        return String.format(Locale.US, "%.2f", valor);
    }

    /** Cambia los caracteres que Helvetica/WinAnsi no puede mostrar. */
    private static String limpiar(String texto) {
        StringBuilder sb = new StringBuilder();
        for (char c : texto.toCharArray()) {
            if (c == '\t') {
                sb.append(' ');
            } else if (c < 32) {
                // se descartan caracteres de control
            } else {
                sb.append(c > 255 ? '?' : c);
            }
        }
        return sb.toString();
    }

    /** En PDF los paréntesis y la barra invertida tienen significado: hay que escaparlos. */
    private static String escaparPdf(String texto) {
        return texto.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }

    /** Parte un texto en líneas de máximo 'max' caracteres, cortando por palabras. */
    private static List<String> partirEnLineas(String texto, int max) {
        List<String> lineas = new ArrayList<>();
        StringBuilder actual = new StringBuilder();
        for (String palabra : texto.split(" ")) {
            if (actual.length() + palabra.length() + 1 > max && actual.length() > 0) {
                lineas.add(actual.toString());
                actual.setLength(0);
            }
            if (actual.length() > 0) {
                actual.append(' ');
            }
            actual.append(palabra);
        }
        lineas.add(actual.toString());
        return lineas;
    }
}
