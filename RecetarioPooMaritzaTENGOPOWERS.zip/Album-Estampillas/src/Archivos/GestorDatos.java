package Archivos;

import java.io.File;
import java.io.IOException;

/**
 * TIPO: Java Interface (con métodos default).
 *
 * Es la misma interface del Álbum de Estampillas: da, a cualquier clase que la
 * implemente, la capacidad de guardar y cargar CUALQUIER objeto Serializable en
 * un archivo. Los métodos "default" ya traen su código, así que quien implementa
 * la interface no tiene que escribirlos.
 */
public interface GestorDatos {

    /** Crea la carpeta y el archivo si todavía no existen. */
    default void verificarYCrearArchivo(String rutaArchivo) throws IOException {
        File archivo = new File(rutaArchivo);
        File carpeta = archivo.getParentFile();
        if (carpeta != null && !carpeta.exists()) {
            carpeta.mkdirs();
        }
        if (!archivo.exists()) {
            archivo.createNewFile();
        }
    }

    /** Escribe un objeto Serializable en el archivo (T = el tipo que se quiera guardar). */
    default <T extends java.io.Serializable> void guardarDatoSerializado(String rutaArchivo, T objeto)
            throws IOException {
        verificarYCrearArchivo(rutaArchivo);
        try (java.io.ObjectOutputStream oos = new java.io.ObjectOutputStream(
                new java.io.FileOutputStream(rutaArchivo))) {
            oos.writeObject(objeto);
        }
    }

    /** Lee un objeto del archivo; el tipo de retorno lo deduce Java según donde se guarde. */
    @SuppressWarnings("unchecked")
    default <T extends java.io.Serializable> T cargarDatoSerializado(String rutaArchivo)
            throws IOException, ClassNotFoundException {
        try (java.io.ObjectInputStream ois = new java.io.ObjectInputStream(new java.io.FileInputStream(rutaArchivo))) {
            return (T) ois.readObject();
        }
    }
}
