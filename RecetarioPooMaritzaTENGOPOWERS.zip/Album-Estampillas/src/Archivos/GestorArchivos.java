package Archivos;

import Control.CategoriaEnum;
import Control.Receta;
import Control.Usuario;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * TIPO: Java Class que IMPLEMENTA la interface GestorDatos.
 *
 * Es el único que sabe DÓNDE y CÓMO se guardan los datos (en la carpeta data/):
 *   data/usuarios.ser  -> HashMap de usuarios
 *   data/recetas.ser   -> ArrayList de recetas
 *   data/imagenes/     -> fotos que sube el administrador
 *   data/pdf/          -> recetas exportadas
 *
 * Mejora respecto al Álbum: los métodos guardar... AVISAN si fallan (throws
 * IOException) en vez de solo imprimir en consola; así la ventana puede
 * decirle al usuario que no se pudo guardar.
 */
public class GestorArchivos implements GestorDatos {

    public static final String RUTA_DATOS = "data" + File.separator;
    public static final String ARCHIVO_USUARIOS = RUTA_DATOS + "usuarios.ser";
    public static final String ARCHIVO_RECETAS = RUTA_DATOS + "recetas.ser";
    public static final File CARPETA_IMAGENES = new File(RUTA_DATOS + "imagenes");
    public static final File CARPETA_PDF = new File(RUTA_DATOS + "pdf");

    // Rutas DENTRO de src (viajan empaquetadas con el programa; solo lectura).
    public static final String RECURSO_RECETAS_INICIALES = "/Recursos/recetas_iniciales.txt";
    public static final String PAQUETE_IMAGENES = "/Imagenes/";

    // ------------------------------------------------------------------
    //  Usuarios
    // ------------------------------------------------------------------

    public void guardarUsuario(HashMap<String, Usuario> usuarios) throws IOException {
        guardarDatoSerializado(ARCHIVO_USUARIOS, usuarios);
    }

    /** Devuelve los usuarios guardados, o null si todavía no hay archivo (primera vez). */
    public HashMap<String, Usuario> cargarUsuario() {
        if (!new File(ARCHIVO_USUARIOS).exists()) {
            return null;
        }
        try {
            return cargarDatoSerializado(ARCHIVO_USUARIOS);
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            System.err.println("Error al cargar los usuarios: " + e.getMessage());
            return null;
        }
    }

    // ------------------------------------------------------------------
    //  Recetas
    // ------------------------------------------------------------------

    public void guardarRecetas(ArrayList<Receta> recetas) throws IOException {
        guardarDatoSerializado(ARCHIVO_RECETAS, recetas);
    }

    /** Devuelve las recetas guardadas, o null si todavía no hay archivo (primera vez). */
    public ArrayList<Receta> cargarRecetas() {
        if (!new File(ARCHIVO_RECETAS).exists()) {
            return null;
        }
        try {
            return cargarDatoSerializado(ARCHIVO_RECETAS);
        } catch (IOException | ClassNotFoundException | ClassCastException e) {
            System.err.println("Error al cargar las recetas: " + e.getMessage());
            return null;
        }
    }

    /**
     * Lee las 60 recetas iniciales de src/Recursos/recetas_iniciales.txt.
     * Formato por línea: clave|nombre|CATEGORIA|ingredientes|preparacion|tiempo|porciones|imagen
     * Dentro de ingredientes y preparación, "\n" separa líneas.
     */
    public ArrayList<Receta> cargarRecetasIniciales() throws IOException {
        ArrayList<Receta> recetas = new ArrayList<>();
        // getResourceAsStream lee un archivo que viaja DENTRO del programa.
        try (InputStream in = getClass().getResourceAsStream(RECURSO_RECETAS_INICIALES)) {
            if (in == null) {
                throw new IOException("No se encontró " + RECURSO_RECETAS_INICIALES);
            }
            BufferedReader lector = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String linea;
            int numeroLinea = 0;
            while ((linea = lector.readLine()) != null) {
                numeroLinea++;
                if (linea.isBlank() || linea.startsWith("#")) {
                    continue;   // se ignoran líneas vacías y comentarios
                }
                String[] c = linea.split("\\|", -1);   // -1 conserva los campos vacíos del final
                try {
                    if (c.length != 8) {
                        throw new IllegalArgumentException("se esperaban 8 campos y hay " + c.length);
                    }
                    recetas.add(new Receta(
                            c[0].trim(),
                            c[1].trim(),
                            CategoriaEnum.valueOf(c[2].trim()),
                            c[3].replace("\\n", "\n"),
                            c[4].replace("\\n", "\n"),
                            Integer.parseInt(c[5].trim()),
                            Integer.parseInt(c[6].trim()),
                            c[7].trim()));
                } catch (RuntimeException e) {
                    throw new IOException("Línea " + numeroLinea + " de recetas_iniciales.txt inválida: " + e.getMessage(), e);
                }
            }
        }
        return recetas;
    }

    /** Crea las carpetas de imágenes y PDF si no existen. */
    public static void crearCarpetas() {
        CARPETA_IMAGENES.mkdirs();
        CARPETA_PDF.mkdirs();
    }
}
