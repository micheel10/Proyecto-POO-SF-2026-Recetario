package Archivos;

import Control.CategoriaEnum;
import Control.Receta;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 * TIPO: Java Class de utilidades (final + métodos static).
 *
 * Se encarga de las FOTOS de las recetas:
 *  - leer sus dimensiones (para validar la resolución),
 *  - guardar la que sube el administrador (en data/imagenes),
 *  - cargarla cuando hay que mostrarla,
 *  - fabricar una imagen de relleno si la receta aún no tiene foto.
 *
 * ORDEN DE BÚSQUEDA al cargar una foto:
 *   1) data/imagenes/<archivo>      (las que sube el administrador)
 *   2) paquete Imagenes dentro de src (las fotos que viajan con el programa)
 *   3) imagen de relleno generada por código (nunca se queda sin imagen)
 */
public final class GestorImagenes {

    // Límites de resolución que usa el validador (requisito: "las imágenes (resolución)")
    public static final int ANCHO_MINIMO = 400;
    public static final int ALTO_MINIMO = 300;
    public static final int ANCHO_MAXIMO = 6000;
    public static final int ALTO_MAXIMO = 6000;
    public static final long PESO_MAXIMO_BYTES = 10L * 1024 * 1024;   // 10 MB

    // Las fotos guardadas se reducen a este ancho máximo (ahorra memoria y PDF más ligero)
    private static final int ANCHO_GUARDADO = 1200;

    // Caché: evita leer del disco la misma foto cada vez que se refresca la pantalla.
    private static final Map<String, BufferedImage> CACHE = new HashMap<>();

    private GestorImagenes() { }

    /**
     * Lee ancho y alto SIN cargar toda la imagen en memoria.
     * Devuelve null si el archivo no es una imagen válida.
     */
    public static Dimension leerDimensiones(File archivo) throws IOException {
        try (ImageInputStream in = ImageIO.createImageInputStream(archivo)) {
            if (in == null) {
                return null;
            }
            Iterator<ImageReader> lectores = ImageIO.getImageReaders(in);
            if (!lectores.hasNext()) {
                return null;   // ningún lector reconoce el formato: no es imagen
            }
            ImageReader lector = lectores.next();
            try {
                lector.setInput(in);
                return new Dimension(lector.getWidth(0), lector.getHeight(0));
            } finally {
                lector.dispose();   // libera recursos del lector
            }
        }
    }

    /**
     * Copia la imagen elegida a data/imagenes, convertida a JPG y reducida.
     * Devuelve SOLO el nombre del archivo guardado (es lo que se anota en la receta).
     */
    public static String guardar(File origen, String clave) throws IOException {
        GestorArchivos.crearCarpetas();
        BufferedImage original = ImageIO.read(origen);
        if (original == null) {
            throw new IOException("El archivo no es una imagen válida.");
        }
        BufferedImage rgb = aRgb(original, ANCHO_GUARDADO);

        // Nombre único (clave + hora) para no pisar imágenes de otras recetas.
        String nombre = clave + "_" + System.currentTimeMillis() + ".jpg";
        ImageIO.write(rgb, "jpg", new File(GestorArchivos.CARPETA_IMAGENES, nombre));
        return nombre;
    }

    /** Borra una imagen subida por el administrador. NUNCA toca las del paquete Imagenes. */
    public static void eliminar(String nombreArchivo) {
        if (nombreArchivo == null || nombreArchivo.isEmpty()) {
            return;
        }
        new File(GestorArchivos.CARPETA_IMAGENES, nombreArchivo).delete();
        CACHE.remove(nombreArchivo);
    }

    /** Devuelve la imagen de la receta (real o de relleno). Nunca devuelve null. */
    public static BufferedImage cargar(Receta receta) {
        String nombre = receta.getImagen();
        if (nombre != null && !nombre.isEmpty()) {
            BufferedImage guardada = CACHE.get(nombre);
            if (guardada != null) {
                return guardada;
            }
            try {
                BufferedImage leida = buscarEnDisco(nombre);
                if (leida != null) {
                    CACHE.put(nombre, leida);
                    return leida;
                }
            } catch (IOException e) {
                // Si falla la lectura, caemos al relleno en vez de romper la pantalla.
            }
        }
        return crearImagenRelleno(receta);
    }

    // ------------------------------------------------------------------
    //  Métodos privados
    // ------------------------------------------------------------------

    private static BufferedImage buscarEnDisco(String nombre) throws IOException {
        File externa = new File(GestorArchivos.CARPETA_IMAGENES, nombre);
        if (externa.exists()) {
            return ImageIO.read(externa);
        }
        // Si no está fuera, buscamos dentro del paquete Imagenes (dentro de src).
        try (InputStream in = GestorImagenes.class.getResourceAsStream(GestorArchivos.PAQUETE_IMAGENES + nombre)) {
            return (in == null) ? null : ImageIO.read(in);
        }
    }

    /** Convierte a RGB (JPG no admite transparencia) y reduce si es muy ancha. */
    private static BufferedImage aRgb(BufferedImage origen, int anchoMaximo) {
        double escala = Math.min(1.0, (double) anchoMaximo / origen.getWidth());
        int w = (int) (origen.getWidth() * escala);
        int h = (int) (origen.getHeight() * escala);
        BufferedImage rgb = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgb.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, h);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(origen, 0, 0, w, h, null);
        g.dispose();
        return rgb;
    }

    /** Dibuja por código una imagen con degradado, la categoría y el nombre de la receta. */
    private static BufferedImage crearImagenRelleno(Receta receta) {
        int w = 800, h = 520;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        Color base = colorDeCategoria(receta.getCategoria());
        g.setPaint(new GradientPaint(0, 0, base.brighter(), w, h, base.darker()));
        g.fillRect(0, 0, w, h);

        g.setColor(new Color(255, 255, 255, 220));
        g.setFont(new Font("SansSerif", Font.BOLD, 30));
        g.drawString(receta.getCategoria().getNombre().toUpperCase(), 150, 130);

        // Nombre de la receta, partido en varias líneas si es largo.
        g.setFont(new Font("Serif", Font.BOLD, 50));
        FontMetrics fm = g.getFontMetrics();
        int y = h / 2 - 10;
        StringBuilder linea = new StringBuilder();
        for (String palabra : receta.getNombre().split(" ")) {
            if (fm.stringWidth(linea + palabra) > w - 300 && linea.length() > 0) {
                g.drawString(linea.toString().trim(), 150, y);
                y += fm.getHeight();
                linea.setLength(0);
            }
            linea.append(palabra).append(' ');
        }
        g.drawString(linea.toString().trim(), 150, y);
        g.dispose();
        return img;
    }

    private static Color colorDeCategoria(CategoriaEnum c) {
        switch (c) {
            case DESAYUNOS:  return new Color(230, 150, 40);
            case POSTRES:    return new Color(200, 80, 130);
            case COMIDAS:    return new Color(60, 130, 80);
            case BEBIDAS:    return new Color(50, 130, 190);
            case CENAS:      return new Color(90, 80, 150);
            default:         return new Color(190, 110, 70);   // MERIENDAS
        }
    }
}
