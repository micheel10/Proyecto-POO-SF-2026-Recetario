package Control;

/**
 * TIPO: Java Enum.
 *
 * Equivale a EquipoEnum del Álbum: allí cada equipo traía nombre, liga y logo;
 * aquí cada categoría trae su nombre y una descripción.
 *
 * El ORDEN de declaración es el que pide el PDF (desayunos, postres, comidas,
 * bebidas, cenas, meriendas): Java ordena los enums por su posición, así que
 * al ordenar las recetas saldrán en ese orden sin escribir más código.
 */
public enum CategoriaEnum {
    DESAYUNOS("Desayunos", "Para empezar bien el día"),
    POSTRES("Postres", "Dulces para cerrar con broche de oro"),
    COMIDAS("Comidas", "Platos fuertes y guisos"),
    BEBIDAS("Bebidas", "Aguas, licuados y bebidas calientes"),
    CENAS("Cenas", "Opciones ligeras para la noche"),
    MERIENDAS("Meriendas", "Botanas y snacks");

    private final String nombre;
    private final String descripcion;

    CategoriaEnum(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    /** Lo que se muestra dentro de un JComboBox o al concatenar texto. */
    @Override
    public String toString() {
        return nombre;
    }
}
