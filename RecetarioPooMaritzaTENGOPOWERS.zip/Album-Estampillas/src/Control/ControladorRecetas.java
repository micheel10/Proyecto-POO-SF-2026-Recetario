package Control;

import Archivos.GeneradorPDF;
import Archivos.GestorArchivos;
import Archivos.GestorImagenes;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;

/**
 * TIPO: Java Class (controlador).
 *
 * Equivale a ControladorEquipos del Álbum. Aquí vive la lógica del recetario:
 * agregar, modificar, consultar y eliminar, más las validaciones de negocio
 * (claves y nombres no repetidos).
 *
 * En el Álbum cada Equipo guardaba sus tarjetas; aquí no hace falta una clase
 * intermedia: la categoría es un dato de la Receta, y filtrar() la separa.
 *
 * Cada cambio se guarda de inmediato en data/recetas.ser. Si el guardado falla,
 * el cambio se DESHACE (así lista y archivo nunca quedan distintos).
 */
public class ControladorRecetas {
    private GestorArchivos gestorArchivos;
    private ArrayList<Receta> listaRecetas;

    public ControladorRecetas(GestorArchivos gestorArchivos) {
        this.gestorArchivos = gestorArchivos;
        listaRecetas = cargarRecetasExistentes();
        inicializarRecetasPredefinidas();
    }

    private ArrayList<Receta> cargarRecetasExistentes() {
        ArrayList<Receta> recetasCargadas = gestorArchivos.cargarRecetas();
        if (recetasCargadas != null) {
            return recetasCargadas;
        } else {
            return new ArrayList<>();
        }
    }

    /** Primera ejecución: carga las 60 recetas iniciales (10 por categoría). */
    public void inicializarRecetasPredefinidas() {
        if (listaRecetas.isEmpty()) {
            try {
                listaRecetas = gestorArchivos.cargarRecetasIniciales();
                gestorArchivos.guardarRecetas(listaRecetas);
            } catch (IOException e) {
                System.err.println("No se pudieron cargar las recetas iniciales: " + e.getMessage());
            }
        }
    }

    // ------------------------------------------------------------------
    //  CONSULTAR
    // ------------------------------------------------------------------

    /** Copia de la lista (así nadie de afuera puede alterar la original). */
    public ArrayList<Receta> getListaRecetas() {
        return new ArrayList<>(listaRecetas);
    }

    /** Recetas ordenadas por categoría (orden del PDF) y luego por nombre. */
    public ArrayList<Receta> listarOrdenadas() {
        ArrayList<Receta> copia = getListaRecetas();
        copia.sort(Comparator.comparing(Receta::getCategoria)
                .thenComparing(Receta::getNombre, String.CASE_INSENSITIVE_ORDER));
        return copia;
    }

    /** Filtra por categoría (null = todas) y por texto (en nombre o clave). */
    public ArrayList<Receta> filtrar(CategoriaEnum categoria, String texto) {
        String buscado = (texto == null) ? "" : texto.trim().toLowerCase();
        ArrayList<Receta> resultado = new ArrayList<>();
        for (Receta r : listarOrdenadas()) {
            boolean coincideCategoria = (categoria == null || r.getCategoria() == categoria);
            boolean coincideTexto = buscado.isEmpty()
                    || r.getNombre().toLowerCase().contains(buscado)
                    || r.getClave().toLowerCase().contains(buscado);
            if (coincideCategoria && coincideTexto) {
                resultado.add(r);
            }
        }
        return resultado;
    }

    /** Busca por clave (sin importar mayúsculas). Devuelve null si no existe. */
    public Receta buscarPorClave(String clave) {
        if (clave == null) {
            return null;
        }
        for (Receta r : listaRecetas) {
            if (r.getClave().equalsIgnoreCase(clave.trim())) {
                return r;
            }
        }
        return null;
    }

    public int getCantidadRecetas() {
        return listaRecetas.size();
    }

    // ------------------------------------------------------------------
    //  AGREGAR
    // ------------------------------------------------------------------

    public void agregarReceta(String clave, String nombre, CategoriaEnum categoria, String ingredientes,
            String preparacion, String tiempo, String porciones, File imagen) throws ValidacionException {
        Receta nueva = validar(clave, nombre, categoria, ingredientes, preparacion, tiempo, porciones, imagen, null);
        if (imagen == null) {
            throw new ValidacionException("Debes seleccionar la imagen del producto terminado.");
        }

        String nombreImagen;
        try {
            nombreImagen = GestorImagenes.guardar(imagen, nueva.getClave());
        } catch (IOException e) {
            throw new ValidacionException("No se pudo guardar la imagen: " + e.getMessage());
        }
        nueva.setImagen(nombreImagen);

        listaRecetas.add(nueva);
        try {
            gestorArchivos.guardarRecetas(listaRecetas);
            generarPdf(nueva);
        } catch (IOException e) {
            listaRecetas.remove(nueva);            // deshacer
            GestorImagenes.eliminar(nombreImagen);
            throw new ValidacionException("No se pudo guardar la receta: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    //  MODIFICAR (se localiza por la clave original; la clave también puede cambiar)
    // ------------------------------------------------------------------

    public void modificarReceta(String claveOriginal, String clave, String nombre, CategoriaEnum categoria,
            String ingredientes, String preparacion, String tiempo, String porciones, File imagen)
            throws ValidacionException {
        Receta existente = buscarPorClave(claveOriginal);
        if (existente == null) {
            throw new ValidacionException("No existe una receta con la clave " + claveOriginal + ".");
        }
        Receta cambios = validar(clave, nombre, categoria, ingredientes, preparacion, tiempo, porciones, imagen,
                existente.getClave());

        // Si eligió una imagen nueva se guarda; la anterior se borra hasta el final.
        String imagenAnterior = existente.getImagen();
        String imagenFinal = imagenAnterior;
        if (imagen != null) {
            try {
                imagenFinal = GestorImagenes.guardar(imagen, cambios.getClave());
            } catch (IOException e) {
                throw new ValidacionException("No se pudo guardar la imagen: " + e.getMessage());
            }
        }
        cambios.setImagen(imagenFinal);

        // Reemplazamos en la MISMA posición y guardamos; si falla, restauramos.
        int posicion = listaRecetas.indexOf(existente);
        listaRecetas.set(posicion, cambios);
        try {
            gestorArchivos.guardarRecetas(listaRecetas);
        } catch (IOException e) {
            listaRecetas.set(posicion, existente);   // deshacer
            if (imagen != null) {
                GestorImagenes.eliminar(imagenFinal);
            }
            throw new ValidacionException("No se pudo guardar la receta: " + e.getMessage());
        }

        if (imagen != null) {
            GestorImagenes.eliminar(imagenAnterior);
        }
        if (!existente.getClave().equals(cambios.getClave())) {
            new File(GestorArchivos.CARPETA_PDF, existente.getClave() + ".pdf").delete();
        }
        try {
            generarPdf(cambios);
        } catch (IOException e) {
            System.err.println("No se pudo regenerar el PDF: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    //  ELIMINAR (borra TODO: datos, imagen y PDF)
    // ------------------------------------------------------------------

    public void eliminarReceta(String clave) throws ValidacionException {
        Receta existente = buscarPorClave(clave);
        if (existente == null) {
            throw new ValidacionException("No existe una receta con la clave " + clave + ".");
        }
        int posicion = listaRecetas.indexOf(existente);
        listaRecetas.remove(existente);
        try {
            gestorArchivos.guardarRecetas(listaRecetas);
        } catch (IOException e) {
            listaRecetas.add(posicion, existente);   // deshacer
            throw new ValidacionException("No se pudo eliminar la receta: " + e.getMessage());
        }
        GestorImagenes.eliminar(existente.getImagen());
        new File(GestorArchivos.CARPETA_PDF, existente.getClave() + ".pdf").delete();
    }

    // ------------------------------------------------------------------
    //  IMÁGENES Y PDF (las pantallas los piden por aquí)
    // ------------------------------------------------------------------

    /** Imagen de la receta; si no tiene (o no se encuentra) devuelve una de relleno. Nunca es null. */
    public BufferedImage cargarImagen(Receta receta) {
        return GestorImagenes.cargar(receta);
    }

    /** Genera (o regenera) data/pdf/<clave>.pdf y devuelve el archivo. */
    public File generarPdf(Receta receta) throws IOException {
        GestorArchivos.crearCarpetas();
        File destino = new File(GestorArchivos.CARPETA_PDF, receta.getClave() + ".pdf");
        GeneradorPDF.generar(receta, cargarImagen(receta), destino);
        return destino;
    }

    /** Genera el PDF y lo copia a donde eligió la persona ("Descargar"). */
    public void exportarPdf(Receta receta, File destino) throws IOException {
        File original = generarPdf(receta);
        Files.copy(original.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    // ------------------------------------------------------------------
    //  VALIDACIÓN (privado: solo lo usan agregar y modificar)
    // ------------------------------------------------------------------

    /**
     * Valida todos los campos y devuelve una Receta nueva (sin imagen todavía).
     * 'claveOriginal' es la clave de la receta que se edita (null al agregar):
     * así una receta no cuenta como "repetida" consigo misma.
     */
    private Receta validar(String clave, String nombre, CategoriaEnum categoria, String ingredientes,
            String preparacion, String tiempo, String porciones, File imagen, String claveOriginal)
            throws ValidacionException {
        String claveLimpia = Validador.clave(clave);
        Receta conEsaClave = buscarPorClave(claveLimpia);
        if (conEsaClave != null && !conEsaClave.getClave().equalsIgnoreCase(claveOriginal)) {
            throw new ValidacionException("Ya existe una receta con la clave " + claveLimpia + ".");
        }

        String nombreLimpio = Validador.textoObligatorio(nombre, "Nombre de la receta", 80);
        for (Receta r : listaRecetas) {
            boolean mismoNombre = r.getNombre().equalsIgnoreCase(nombreLimpio);
            boolean esLaMisma = r.getClave().equalsIgnoreCase(claveOriginal);
            if (mismoNombre && !esLaMisma) {
                throw new ValidacionException("La receta \"" + nombreLimpio + "\" ya está registrada.");
            }
        }

        if (categoria == null) {
            throw new ValidacionException("Selecciona una categoría.");
        }
        String ingredientesLimpios = Validador.textoObligatorio(ingredientes, "Ingredientes", 3000);
        String preparacionLimpia = Validador.textoObligatorio(preparacion, "Modo de preparación", 5000);
        int minutos = Validador.entero(tiempo, "Tiempo de cocción (minutos)", 1, 1440);
        int numPorciones = Validador.entero(porciones, "Porciones", 1, 100);

        if (imagen != null) {
            Validador.imagen(imagen);
        }
        return new Receta(claveLimpia, nombreLimpio, categoria, ingredientesLimpios, preparacionLimpia,
                minutos, numPorciones, "");
    }
}
