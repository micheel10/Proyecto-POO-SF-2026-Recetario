package Control;

/**
 * TIPO: Java Class ABSTRACTA (no se puede hacer new Usuario(...)).
 *
 * Es la clase padre de Administrador y UsuarioComun. Implementa Serializable
 * para poder guardarse en data/usuarios.ser (igual que en el Álbum).
 * serialVersionUID identifica la "versión" de la clase al leer el archivo.
 */
public abstract class Usuario implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private String nombreUsuario;
    private String contraseniaUsuario;
    private RolEnum tipoUsuario;

    public Usuario(String nombreUsuario, String contraseniaUsuario, RolEnum tipoUsuario) {
        this.nombreUsuario = nombreUsuario.toLowerCase();
        this.contraseniaUsuario = contraseniaUsuario;
        this.tipoUsuario = tipoUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContrasenia() {
        return contraseniaUsuario;
    }

    public RolEnum getTipoUsuario() {
        return tipoUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario.toLowerCase();
    }

    public void setContrasenia(String contraseniaUsuario) {
        this.contraseniaUsuario = contraseniaUsuario;
    }

    public void setTipoUsuario(RolEnum tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
}
