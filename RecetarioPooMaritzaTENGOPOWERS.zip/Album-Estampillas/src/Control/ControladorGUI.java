package Control;

import GUI.AdminGUI;
import GUI.AgregarModificarRecetaGUI;
import GUI.InicioSesionGUI;
import GUI.RecetaGUI;
import GUI.RecetarioGUI;
import GUI.RegistroGUI;

/**
 * TIPO: Java Class (controlador).
 *
 * Igual que en el Álbum: es quien CREA, MUESTRA y OCULTA las ventanas.
 * Las ventanas "únicas" (inicio de sesión, registro, panel admin, recetario)
 * se crean la primera vez que se piden y después se reutilizan.
 *
 * Mejoras respecto al Álbum:
 *  - cerrarSesion() descarta TODAS las ventanas de la sesión. Antes, el panel
 *    de administración se quedaba guardado y, si entraba otra persona después,
 *    se mostraba con el usuario anterior.
 *  - El formulario de recetas también se abre desde aquí (mostrarFormularioReceta),
 *    para que ninguna pantalla cree a otra por su cuenta.
 */
public class ControladorGUI {
    private InicioSesionGUI inicioSesion;
    private RegistroGUI registro;
    private RecetarioGUI recetario;
    private AdminGUI adminPanel;
    private ControladorPrincipal controladorPrincipal;
    private Usuario usuarioAdmin;

    public ControladorGUI(ControladorPrincipal controladorPrincipal) {
        this.controladorPrincipal = controladorPrincipal;
    }

    // ---------- Inicio de sesión ----------
    public void mostrarInicioSesion() {
        if (inicioSesion == null) {
            inicioSesion = new InicioSesionGUI(controladorPrincipal);
        }
        inicioSesion.setVisible(true);
    }

    public void ocultarInicioSesion() {
        if (inicioSesion != null) {
            inicioSesion.setVisible(false);
            inicioSesion.limpiarCampos();
        }
    }

    // ---------- Registro ----------
    public void mostrarRegistro() {
        if (registro == null) {
            registro = new RegistroGUI(controladorPrincipal);
        }
        registro.setVisible(true);
    }

    public void ocultarRegistro() {
        if (registro != null) {
            registro.setVisible(false);
            registro.limpiarCampos();
        }
    }

    // ---------- Panel del administrador ----------
    public void setUsuarioAdmin(Usuario usuario) {
        this.usuarioAdmin = usuario;
    }

    public void mostrarAdminPanel() {
        if (adminPanel == null) {
            adminPanel = new AdminGUI(controladorPrincipal, usuarioAdmin);
        }
        adminPanel.setVisible(true);
    }

    public void ocultarAdminPanel() {
        if (adminPanel != null) {
            adminPanel.setVisible(false);
        }
    }

    // ---------- Recetario (equivale al Álbum) ----------
    public void mostrarRecetario(Usuario usuario) {
        if (usuario != null) {
            if (recetario == null || !recetario.isVisible()) {
                recetario = new RecetarioGUI(usuario, controladorPrincipal);
            }
            recetario.setVisible(true);
        }
    }

    public void ocultarRecetario() {
        if (recetario != null) {
            recetario.setVisible(false);
        }
    }

    /** Vuelve a dibujar las tarjetas (se llama tras agregar, modificar o eliminar). */
    public void recargarRecetario() {
        if (recetario != null && recetario.isVisible()) {
            recetario.recargarRecetario();
        }
    }

    // ---------- Detalle y formulario de recetas ----------
    public void mostrarReceta(Receta receta) {
        if (receta != null) {
            RecetaGUI recetaGUI = new RecetaGUI(receta, controladorPrincipal);
            recetaGUI.setVisible(true);
        }
    }

    /** receta == null abre el formulario para AGREGAR; con una receta, para MODIFICARLA. */
    public void mostrarFormularioReceta(Receta receta) {
        AgregarModificarRecetaGUI formulario = (receta == null)
                ? new AgregarModificarRecetaGUI(controladorPrincipal)
                : new AgregarModificarRecetaGUI(controladorPrincipal, receta);
        formulario.setVisible(true);
    }

    // ---------- Cierre de sesión ----------
    public void cerrarSesion() {
        if (recetario != null) {
            recetario.dispose();
            recetario = null;
        }
        if (adminPanel != null) {
            adminPanel.dispose();
            adminPanel = null;
        }
        usuarioAdmin = null;
        mostrarInicioSesion();
    }
}
