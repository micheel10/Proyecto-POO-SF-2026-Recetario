package Control;

/**
 * TIPO: Java Enum.
 * Los dos tipos de usuario del sistema (igual que en el Álbum de Estampillas).
 * toString() decide cómo se ve el valor en el ComboBox del registro.
 */
public enum RolEnum {
    USUARIO("Usuario"),
    ADMINISTRADOR("Administrador");

    private final String nombre;

    RolEnum(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
