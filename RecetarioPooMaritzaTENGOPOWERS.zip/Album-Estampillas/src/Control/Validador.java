package Control;

import Archivos.GestorImagenes;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;

/**
 * TIPO: Java Class de utilidades (final + métodos static).
 *
 * Todas las reglas de validación en un solo lugar: campos llenos, tipos de
 * dato y resolución de imágenes. Cada método devuelve el valor ya limpio o
 * lanza ValidacionException con un mensaje claro.
 */
public final class Validador {

    private static final Pattern PATRON_CLAVE = Pattern.compile("[A-Za-z0-9-]{3,10}");
    private static final Pattern PATRON_USUARIO = Pattern.compile("[a-z0-9_]{3,15}");

    private Validador() { }

    /** Clave de receta: de 3 a 10 caracteres (letras, números o guion). Se guarda en MAYÚSCULAS. */
    public static String clave(String valor) throws ValidacionException {
        String limpia = (valor == null) ? "" : valor.trim();
        if (limpia.isEmpty()) {
            throw new ValidacionException("La clave no puede estar vacía.");
        }
        if (!PATRON_CLAVE.matcher(limpia).matches()) {
            throw new ValidacionException(
                    "La clave debe tener de 3 a 10 caracteres (letras, números o guion). Ejemplo: DES-01");
        }
        return limpia.toUpperCase();
    }

    /** Nombre de usuario: 3 a 15 caracteres, solo minúsculas, números o guion bajo. */
    public static String nombreUsuario(String valor) throws ValidacionException {
        String limpio = (valor == null) ? "" : valor.trim().toLowerCase();
        if (!PATRON_USUARIO.matcher(limpio).matches()) {
            throw new ValidacionException(
                    "El usuario debe tener de 3 a 15 caracteres (letras, números o guion bajo, sin espacios).");
        }
        return limpio;
    }

    /** Contraseña: mínimo 4 caracteres. */
    public static String contrasenia(String valor) throws ValidacionException {
        if (valor == null || valor.trim().length() < 4) {
            throw new ValidacionException("La contraseña debe tener al menos 4 caracteres.");
        }
        return valor.trim();
    }

    /** Texto obligatorio con longitud máxima. 'campo' es el nombre que verá el usuario en el mensaje. */
    public static String textoObligatorio(String valor, String campo, int maximo) throws ValidacionException {
        String limpio = (valor == null) ? "" : valor.trim();
        if (limpio.isEmpty()) {
            throw new ValidacionException("El campo «" + campo + "» no puede estar vacío.");
        }
        if (limpio.length() > maximo) {
            throw new ValidacionException("El campo «" + campo + "» no puede superar los " + maximo + " caracteres.");
        }
        return limpio;
    }

    /** Convierte un texto a número entero dentro de un rango. */
    public static int entero(String valor, String campo, int minimo, int maximo) throws ValidacionException {
        String limpio = (valor == null) ? "" : valor.trim();
        if (limpio.isEmpty()) {
            throw new ValidacionException("El campo «" + campo + "» no puede estar vacío.");
        }
        try {
            int numero = Integer.parseInt(limpio);   // lanza NumberFormatException si no es número
            if (numero < minimo || numero > maximo) {
                throw new ValidacionException("El campo «" + campo + "» debe estar entre " + minimo + " y " + maximo + ".");
            }
            return numero;
        } catch (NumberFormatException e) {
            throw new ValidacionException("El campo «" + campo + "» debe ser un número entero (sin letras ni decimales).");
        }
    }

    /** Comprueba que el archivo sea una imagen, no pese demasiado y tenga buena resolución. */
    public static void imagen(File archivo) throws ValidacionException {
        if (archivo == null || !archivo.isFile()) {
            throw new ValidacionException("El archivo de imagen no existe.");
        }
        if (archivo.length() > GestorImagenes.PESO_MAXIMO_BYTES) {
            throw new ValidacionException("La imagen pesa demasiado (máximo 10 MB).");
        }
        try {
            Dimension d = GestorImagenes.leerDimensiones(archivo);
            if (d == null) {
                throw new ValidacionException("El archivo seleccionado no es una imagen válida (usa JPG o PNG).");
            }
            if (d.width < GestorImagenes.ANCHO_MINIMO || d.height < GestorImagenes.ALTO_MINIMO) {
                throw new ValidacionException("La imagen es muy pequeña (" + d.width + "x" + d.height
                        + "). Mínimo " + GestorImagenes.ANCHO_MINIMO + "x" + GestorImagenes.ALTO_MINIMO + " píxeles.");
            }
            if (d.width > GestorImagenes.ANCHO_MAXIMO || d.height > GestorImagenes.ALTO_MAXIMO) {
                throw new ValidacionException("La imagen es demasiado grande (" + d.width + "x" + d.height
                        + "). Máximo " + GestorImagenes.ANCHO_MAXIMO + "x" + GestorImagenes.ALTO_MAXIMO + " píxeles.");
            }
        } catch (IOException e) {
            throw new ValidacionException("No se pudo leer la imagen: " + e.getMessage());
        }
    }
}
