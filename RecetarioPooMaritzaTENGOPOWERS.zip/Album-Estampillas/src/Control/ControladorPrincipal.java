package Control;

import Archivos.GestorArchivos;

/**
 * TIPO: Java Class (controlador raíz, "centro de mando").
 *
 * Igual que en el Álbum: crea los demás controladores y los reparte.
 * Diferencia: crea UN SOLO GestorArchivos y se lo comparte a los controladores
 * (en el Álbum cada controlador creaba el suyo).
 *
 * REGLA: en un constructor solo se CREAN objetos. Los controladores que
 * necesitan a otro lo piden con getXxx() DENTRO de sus métodos, cuando ya
 * todo existe (si se pidiera aquí, el otro todavía podría ser null).
 */
public class ControladorPrincipal {
    private GestorArchivos gestorArchivos;
    private ControladorUsuario controladorUsuario;
    private ControladorRecetas controladorRecetas;
    private ControladorGUI controladorGUI;

    public ControladorPrincipal() {
        gestorArchivos = new GestorArchivos();
        controladorUsuario = new ControladorUsuario(gestorArchivos);
        controladorRecetas = new ControladorRecetas(gestorArchivos);
        controladorGUI = new ControladorGUI(this);
    }

    public GestorArchivos getGestorArchivos() {
        return gestorArchivos;
    }

    public ControladorUsuario getControladorUsuario() {
        return controladorUsuario;
    }

    public ControladorRecetas getControladorRecetas() {
        return controladorRecetas;
    }

    public ControladorGUI getControladorGUI() {
        return controladorGUI;
    }
}
