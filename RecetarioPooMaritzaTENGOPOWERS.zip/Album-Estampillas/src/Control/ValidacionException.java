package Control;

/**
 * TIPO: Java Class (excepción propia; hereda de Exception).
 *
 * Se lanza cuando un dato no cumple una regla (campo vacío, clave repetida,
 * imagen muy pequeña...). Su mensaje es EXACTAMENTE el texto que la GUI
 * muestra en la ventana emergente. Es "checked": Java obliga a atraparla.
 *
 * Gracias a ella, las pantallas ya no necesitan tener validaciones propias:
 * solo hacen try/catch y muestran el mensaje.
 */
public class ValidacionException extends Exception {

    public ValidacionException(String mensaje) {
        super(mensaje);
    }
}
