package Control;

import java.util.ArrayList;
import java.util.List;

public class Receta implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    private String clave;
    private String nombre;
    private CategoriaEnum categoria;
    private String ingredientes;
    private String preparacion;
    private int tiempoCoccion;   // minutos
    private int porciones;
    private String imagen;       // nombre del archivo; vacío si aún no tiene foto

    public Receta(String clave, String nombre, CategoriaEnum categoria, String ingredientes,
            String preparacion, int tiempoCoccion, int porciones, String imagen) {
        this.clave = clave;
        this.nombre = nombre;
        this.categoria = categoria;
        this.ingredientes = ingredientes;
        this.preparacion = preparacion;
        this.tiempoCoccion = tiempoCoccion;
        this.porciones = porciones;
        this.imagen = imagen;
    }

    public String getClave() { return clave; }
    public String getNombre() { return nombre; }
    public CategoriaEnum getCategoria() { return categoria; }
    public String getIngredientes() { return ingredientes; }
    public String getPreparacion() { return preparacion; }
    public int getTiempoCoccion() { return tiempoCoccion; }
    public int getPorciones() { return porciones; }
    public String getImagen() { return imagen; }

    public void setClave(String clave) { this.clave = clave; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setCategoria(CategoriaEnum categoria) { this.categoria = categoria; }
    public void setIngredientes(String ingredientes) { this.ingredientes = ingredientes; }
    public void setPreparacion(String preparacion) { this.preparacion = preparacion; }
    public void setTiempoCoccion(int tiempoCoccion) { this.tiempoCoccion = tiempoCoccion; }
    public void setPorciones(int porciones) { this.porciones = porciones; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    public List<String> getListaIngredientes() {
        return separarLineas(ingredientes);
    }

    public List<String> getListaPasos() {
        return separarLineas(preparacion);
    }

    /** Parte un texto en líneas, quitando espacios y descartando las vacías. */
    private static List<String> separarLineas(String texto) {
        List<String> lineas = new ArrayList<>();
        for (String linea : texto.split("\\R")) {   // \R = cualquier tipo de salto de línea
            if (!linea.trim().isEmpty()) {
                lineas.add(linea.trim());
            }
        }
        return lineas;
    }

    @Override
    public String toString() {
        return clave + " - " + nombre;
    }
}
