package Control;

import Archivos.GestorArchivos;
import java.io.IOException;
import java.util.HashMap;

/**
 * TIPO: Java Class (controlador).
 *
 * Maneja los usuarios: inicio de sesión y registro. Los usuarios viven en un
 * HashMap (clave = nombre de usuario) que se guarda en data/usuarios.ser.
 *
 * Cambios respecto al Álbum:
 *  - El mapa es privado (antes era public: cualquiera podía modificarlo sin guardarlo).
 *  - La clave de administrador y TODAS las validaciones del registro viven aquí
 *    y no en la pantalla (en el Álbum "ADM9" estaba escrita dentro de RegistroGUI).
 *  - Si es la primera vez, crea dos cuentas de prueba (admin y usuario).
 */
public class ControladorUsuario {
    // Para el proyecto escolar. En un sistema real NO se escribiría aquí.
    private static final String CLAVE_ADMINISTRADOR = "ADM9";

    private GestorArchivos gestorArchivos;
    private HashMap<String, Usuario> usuarios;

    public ControladorUsuario(GestorArchivos gestorArchivos) {
        this.gestorArchivos = gestorArchivos;
        usuarios = cargarUsuariosExistentes();
        inicializarUsuariosPredeterminados();
    }

    private HashMap<String, Usuario> cargarUsuariosExistentes() {
        HashMap<String, Usuario> usuariosCargados = gestorArchivos.cargarUsuario();
        if (usuariosCargados != null) {
            return usuariosCargados;
        } else {
            return new HashMap<>();
        }
    }

    /** Primera ejecución: deja listas las cuentas de prueba. */
    private void inicializarUsuariosPredeterminados() {
        if (usuarios.isEmpty()) {
            usuarios.put("admin", new Administrador("admin", "admin123"));
            usuarios.put("usuario", new UsuarioComun("usuario", "usuario123"));
            try {
                gestorArchivos.guardarUsuario(usuarios);
            } catch (IOException e) {
                System.err.println("No se pudieron guardar los usuarios iniciales: " + e.getMessage());
            }
        }
    }

    /**
     * Registra un usuario nuevo. 'claveAdmin' solo se revisa si el rol es ADMINISTRADOR.
     * Lanza ValidacionException con el mensaje que debe ver la persona.
     */
    public void registrarUsuario(String nombreUsuario, String contrasenia, RolEnum rol, String claveAdmin)
            throws ValidacionException {
        String nombre = Validador.nombreUsuario(nombreUsuario);
        String clave = Validador.contrasenia(contrasenia);

        if (usuarios.containsKey(nombre)) {
            throw new ValidacionException("Este usuario ya existe.");
        }
        if (rol == RolEnum.ADMINISTRADOR
                && (claveAdmin == null || !claveAdmin.trim().equals(CLAVE_ADMINISTRADOR))) {
            throw new ValidacionException("Clave de administrador incorrecta.");
        }

        Usuario nuevo = (rol == RolEnum.ADMINISTRADOR)
                ? new Administrador(nombre, clave)
                : new UsuarioComun(nombre, clave);
        usuarios.put(nombre, nuevo);
        try {
            gestorArchivos.guardarUsuario(usuarios);
        } catch (IOException e) {
            usuarios.remove(nombre);   // si no se pudo guardar, deshacemos el cambio
            throw new ValidacionException("No se pudo guardar el usuario: " + e.getMessage());
        }
    }

    public boolean validarUsuario(String nombreUsuario) {
        return usuarios.containsKey(nombreUsuario);
    }

    public boolean validarContrasenia(String nombreUsuario, String contraseniaUsuario) {
        Usuario usuario = usuarios.get(nombreUsuario);
        return usuario != null && usuario.getContrasenia().equals(contraseniaUsuario);
    }

    public Usuario obtenerUsuario(String nombreUsuario) {
        return usuarios.get(nombreUsuario);
    }
}
