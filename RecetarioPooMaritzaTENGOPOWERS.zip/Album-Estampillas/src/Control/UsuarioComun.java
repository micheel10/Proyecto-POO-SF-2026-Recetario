package Control;

/**
 * TIPO: Java Class (hereda de Usuario).
 * Un usuario con rol USUARIO: solo visualiza el recetario y descarga el PDF.
 */
public class UsuarioComun extends Usuario {

    public UsuarioComun(String nombreUsuario, String contraseniaUsuario) {
        super(nombreUsuario, contraseniaUsuario, RolEnum.USUARIO);
    }
}
