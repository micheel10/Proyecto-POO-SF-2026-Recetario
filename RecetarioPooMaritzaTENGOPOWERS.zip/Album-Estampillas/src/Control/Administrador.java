package Control;

/**
 * TIPO: Java Class (hereda de Usuario).
 * Un usuario con rol ADMINISTRADOR: puede agregar, modificar y eliminar recetas.
 */
public class Administrador extends Usuario {

    public Administrador(String nombreUsuario, String contraseniaUsuario) {
        super(nombreUsuario, contraseniaUsuario, RolEnum.ADMINISTRADOR);
    }
}
